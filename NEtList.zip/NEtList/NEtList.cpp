#include <windows.h>
#include <iostream>
#include <netlistmgr.h>
#include <comdef.h>  // For _com_ptr_t and _bstr_t

#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")

void PrintNetworkInfo(INetwork* network) {
    BSTR name;
    HRESULT hr = network->GetName(&name);
    if (SUCCEEDED(hr)) {
        std::wcout << L"Network Name: " << name << std::endl;
        SysFreeString(name);
    }
    else {
        std::wcerr << L"Failed to get network name." << std::endl;
    }
}

int main() {
    HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
    if (FAILED(hr)) {
        std::cerr << "COM initialization failed." << std::endl;
        return 1;
    }

    INetworkListManager* pNetworkListManager = nullptr;
    hr = CoCreateInstance(
        CLSID_NetworkListManager,
        NULL,
        CLSCTX_ALL,
        IID_INetworkListManager,
        (void**)&pNetworkListManager);

    if (FAILED(hr)) {
        std::cerr << "Failed to create NetworkListManager instance." << std::endl;
        CoUninitialize();
        return 1;
    }

    IEnumNetworks* pEnumNetworks = nullptr;
    hr = pNetworkListManager->GetNetworks(NLM_ENUM_NETWORK_ALL, &pEnumNetworks);
    if (SUCCEEDED(hr)) {
        INetwork* pNetwork = nullptr;
        ULONG fetched = 0;
        while (pEnumNetworks->Next(1, &pNetwork, &fetched) == S_OK && fetched > 0) {
            PrintNetworkInfo(pNetwork);
            pNetwork->Release();
        }
        pEnumNetworks->Release();
    }
    else {
        std::cerr << "Failed to enumerate networks." << std::endl;
    }

    pNetworkListManager->Release();
    CoUninitialize();
    return 0;
}

