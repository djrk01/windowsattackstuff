// background.js

// This function runs when the extension is installed or updated
chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension installed or updated.");
    // You can set default values in storage or perform other setup tasks here
    chrome.storage.sync.set({ color: '#3aa757' }, () => {
        console.log("The color is green.");
    });
});

// Listen for messages from other parts of the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getColor") {
        // Respond with the color stored in storage
        chrome.storage.sync.get("color", (data) => {
            sendResponse({ color: data.color });
        });
        // Indicate that the response will be sent asynchronously
        return true; 
    }
});

// Example of a simple alarm that triggers every minute
chrome.alarms.create("myAlarm", { periodInMinutes: 1 });

// Listen for the alarm event
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "myAlarm") {
        console.log("Alarm triggered!");
        // You can perform actions here, like sending notifications
        chrome.notifications.create({
            type: "basic",
            iconUrl: "images/icon48.png",
            title: "Alarm",
            message: "Your alarm has been triggered!",
            priority: 2
        });
    }
});